#here i imported factorial 
from math import factorial
#here i am reading input.
n = int(input())
for i in range(n):
    #first i arranged spaces
        for j in range(n-i+1):
            print(end=" ")
            #here i used n!/(n-r)!*r!
        for j in range(i+1):
            print(factorial(i)//(factorial(j)*factorial(i-j)), end=" ")
            #this statement is for code comming line by line
        print()